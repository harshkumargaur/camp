require('@dot/env');
const process = require('process');
const path = require('path');
const morgan = require('morgan');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const express = require('express');
const app = express();

app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/public', express.static(path.join(__dirname, 'public')));

// Import the functions you need from the SDKs you need
const firebase = require('firebase-admin');
// const { getAnalytics } = require('firebase/analytics');
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: 'AIzaSyAr6re8R5sATxYDAnRzjlVxKeukFeEVSbA',
  authDomain: 'camp-da60a.firebaseapp.com',
  projectId: 'camp-da60a',
  storageBucket: 'camp-da60a.appspot.com',
  messagingSenderId: '796212270130',
  appId: '1:796212270130:web:ed9e62f8a3d1a2ceeb182b',
  measurementId: 'G-YYL611Y5MM',
};

// Initialize Firebase
// firebase.initializeApp(firebaseConfig);

// const {
//   GoogleAuthProvider,
//   signInWithPopup,
//   getAuth,
// } = require('firebase-admin/auth');
// app.get('/auth/google', async (req, res, next) => {
//   const provider = new firebase.auth.GoogleAuthProvider();
//   provider.addScope('https://www.googleapis.com/auth/contacts.readonly');

//   // auth.useDeviceLanguage();

//   const auth = getAuth();
//   signInWithPopup(auth, provider)
//     .then((result) => {
//       // This gives you a Google Access Token. You can use it to access the Google API.
//       const credential = GoogleAuthProvider.credentialFromResult(result);
//       const token = credential.accessToken;
//       // The signed-in user info.
//       const user = result.user;
//       console.log(user);

//       // IdP data available using getAdditionalUserInfo(result)
//       // ...
//     })
//     .catch((error) => {
//       // Handle Errors here.
//       const errorCode = error.code;
//       const errorMessage = error.message;
//       // The email of the user's account used.
//       const email = error.customData.email;
//       console.log(errorCode, email, errorMessage);

//       // The AuthCredential type that was used.
//       const credential = GoogleAuthProvider.credentialFromError(error);
//       // ...
//     });
//   // auth.languageCode = 'it';
// });
// To apply the default browser preference instead of explicitly setting it.

////models

////controller

//Router
const campRouter = require('./routes/campRoutes');
const userRouter = require('./routes/userRoutes');

app.use('/camp', campRouter);
app.use('/user', userRouter);
///ERROR HANDLER
app.use((err, req, res, next) => {
  res.status(404).json({
    err: err.message,
  });
});

app.listen(process.env.PORT, async (err) => {
  await mongoose.connect(process.env.MONGO_URL);
  console.log('connected');
});

process.on('uncaughtException', (err, origin) => {
  console.error('entered');
  console.error(err);
  console.error(err.message);
  process.exit(0);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(0);
});
